/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 endscreen gameover.jpg 
 * Time-stamp: Saturday 11/11/2017, 20:13:49
 * 
 * Image Information
 * -----------------
 * gameover.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENDSCREEN_H
#define ENDSCREEN_H

extern const unsigned short gameover[38400];
#define GAMEOVER_SIZE 76800
#define GAMEOVER_LENGTH 38400
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160

#endif

