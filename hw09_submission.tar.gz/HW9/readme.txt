This game is called Heli Attack. The aim of this game is to dodge obstacles (in the form of walls) while preventing your helicopter 
from touching the ground (kind of like Flappy Bird). 

To win this game, you have to dodge 20 obstacles. Upon winning, the WIN screen will display.

The helicopter has gravity ie. if the helicopter isn't moving up, it will move downwards. 

You are given three lives. For every time you crash into an obstacle or hit the ground, you lose a life. Every time you lose a life, the screen will reset and you will start from the top-left corner of the screen.
 
Every time you reach the end of the screen, the screen refreshes and the helicopter resumes from the same place.

The obstacles are randomly positioned on the screen with sufficient spacing. 

The number of lives you have left will be displayed on the bottom-left corner of the screen. 

You can return to the homescreen of the game at any time by pressing the SELECT button. 

If you lose all three lives, the DEFEAT screen will display.

I use four backgrounds:
	1) START screen
	2) GAME screen
	3) WIN screen
	4) DEFEAT screen

I use 2 images:
	1) HELICOPTER
	2) WALL

Controls : Right Arrow : move forward
	   Up Arrow : move up
	   Down Arrow : move down
